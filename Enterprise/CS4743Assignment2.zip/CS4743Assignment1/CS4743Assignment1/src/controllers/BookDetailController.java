package controllers;

import java.io.IOException;
import javax.xml.bind.ValidationException;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import application.Books;
import gateway.GatewayException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;



public class BookDetailController {
	private Books book;
	@FXML private TextField title;
	@FXML private TextField isbn;
	@FXML private TextField year;
	@FXML private TextField summary;
	@FXML private Button bookSave;
	
	private static Logger logger = LogManager.getLogger();
	
	@FXML private Button bookDelete;
	@FXML private Button bookAdd;
	
	public BookDetailController(Books book) {
		this.book = book;
	}
	
	@FXML public void handleSave(ActionEvent action) throws IOException {
		Object source = action.getSource();
		if(source == bookSave) {
			save();
		}
	}
	
	@FXML public void handleDelete(ActionEvent action) throws IOException {
		Object source = action.getSource();
		if(source == bookDelete) {
			delete();
		}
	}
	
	@FXML public void handleAdd(ActionEvent action) throws IOException {
		Object source = action.getSource();
		if(source == bookAdd) {
			add();
		}
	}
	
	public boolean save(){
		try {
			logger.info("Begin save");
			book.setTitle(title.getText());
			book.setISBN(isbn.getText());
			book.setSummary(summary.getText());
			book.setYear(Integer.parseInt(year.getText()));
			
			
			book.save();

			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Saved!");
			alert.setHeaderText(null);
			alert.setContentText("The changes have been changed successfully.");
			
			//alert.showAndWait();
			
			} catch (ValidationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return false;
			} catch (GatewayException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return false;
			}	
			return true;
	}
	
	public boolean delete(){
		try {
			logger.info("Begin delete");
			
			book.delete();

			logger.info("Deleted!");
			
			} catch (ValidationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return false;
			} catch (GatewayException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return false;
			}	
			return true;
	}
	
	public boolean add(){
			try {
				
				logger.info("Begin adding...");
				book.setId(book.getId());
				book.setTitle(title.getText());
				book.setISBN(isbn.getText());
				book.setSummary(summary.getText());
				book.setYear(Integer.parseInt(year.getText()));
				
				book.add();
	
				logger.info("Book added!");
				} catch (ValidationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					return false;
				} catch (GatewayException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					return false;
				}	
			return true;
	}

	public void initialize() {
		logger.info("Set text for variables");
		title.setText(book.getTitle());
		isbn.setText(book.getISBN());
		year.setText("" + book.getYear());
		summary.setText(book.getSummary());
	}

}
