package controllers;

import java.io.IOException;
import java.util.List;

import javax.xml.bind.ValidationException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import application.Books;
import gateway.GatewayException;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;
import view.ViewType;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class BookListController{

	private static final Logger logger = LogManager.getLogger();
	private Books book;

	@FXML
	private ListView<Books> bookList;

	private List<Books> books;
	
	

	@FXML private Button bookDelete;

	public BookListController(List<Books> books) {
		this.books = books;
	}
	
	public void initialize() {
		logger.info("Begining of init booklistcont");
		ObservableList<Books> items = bookList.getItems();
		
		items.addAll(books);

		bookList.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent click) {
                if(click.getClickCount() == 2) {
                	Books selected = bookList.getSelectionModel().getSelectedItem();
                   
                	logger.info("User double-clicked");
						MainController.showView(ViewType.BookDetail, selected);
        			
                	
                }
            }
        });

	}
	
	/*@FXML public void handleDelete(ActionEvent action) throws IOException {
		Object source = action.getSource();
		if(source == bookDelete) {
			delete();
		}
	}
	
	
	
	public boolean delete(){
		try {
			logger.info("Begin delete");
			
			
			book.delete();

			logger.info("Deleted!");
			
			} catch (ValidationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return false;
			} catch (GatewayException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return false;
			}	
			return true;
	}*/
	

}


