package controllers;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javafx.application.Platform;
import application.Books;
import gateway.BookGateway;
import gateway.BooksTableGateway;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.layout.BorderPane;
import view.ViewType;

public class MainController{
	private static final Logger logger = LogManager.getLogger();
	
	private static BorderPane rootPane;

	private static BookGateway bookGateway;

	
	private MainController() {
	}
	
	public static void initGateway() throws SQLException {
		logger.info("Init gateway!!!");
		try {
			bookGateway = new BooksTableGateway();
		} catch (Exception e) {
			e.printStackTrace();
			Platform.exit();
		}
	}

	@FXML
    void onBookList(ActionEvent event){
		logger.info("Clicked on Books. Show menuItem 'BookList'");
		
		showView(ViewType.BookList, null);
    }
	
	public static boolean showView(ViewType viewType, Object info){
		FXMLLoader loader = null;
		Parent viewNode;
		switch(viewType) {
			case BookDetail : 
				logger.info("Viewing book detail.");
				loader = new FXMLLoader(MainController.class.getResource("/view/BookDetailView.fxml"));
				logger.info("Book Detail Loaded");
				loader.setController(new BookDetailController((Books) info));
				break;
				
			case BookList : 
				logger.info("Viewing book list.");
				List<Books> books = bookGateway.getBook();
				logger.info("Books loaded.");
				loader = new FXMLLoader(MainController.class.getResource("/view/BookListView.fxml"));
				logger.info("Book List Loaded.");
				loader.setController(new BookListController(books));
				break;
			case BookAdd :
				logger.info("Viewing book detail to add new book.");
				loader = new FXMLLoader(MainController.class.getResource("/view/BookDetailAddView.fxml"));
				logger.info("Book detail for Adding Loaded");
				loader.setController(new BookDetailController((Books) info));
				break;
		}
		
		viewNode = null;
		
		try {
			viewNode = loader.load();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		rootPane.setCenter(viewNode);
		return true;
	}
	

	public static void close() {
		bookGateway.close();
	}
		
	public BorderPane getRootPane() {
		return rootPane;
	}

	public static void setRootPane(BorderPane view) {
		rootPane = view;
	}

	public static BookGateway getBookGateway() {
		return bookGateway;
	}

	public void setBookGateway(BooksTableGateway bookGateway) {
		this.bookGateway = bookGateway;
	}


}
