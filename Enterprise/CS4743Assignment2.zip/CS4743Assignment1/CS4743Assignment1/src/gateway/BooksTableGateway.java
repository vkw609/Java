package gateway;

import com.mysql.cj.jdbc.MysqlDataSource;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import application.Books;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class BooksTableGateway implements BookGateway {
	
	private Connection connector;

	private static Logger logger = LogManager.getLogger();
	
	public List<Books> getBook() {
		logger.info("List<Books>");
		List<Books> books = new ArrayList<Books>();
		PreparedStatement st = null;
		ResultSet result = null;
		
		try {
			logger.info("Try list");
			st = connector.prepareStatement("select BookList.id, BookList.title, BookList.isbn, BookList.year_published, BookList.summary"
					+ " FROM BookList");
			result = st.executeQuery();
			logger.info("ExecuteQ");
			while(result.next()) {
				Books book = new Books(result.getInt("id"), result.getString("title"), result.getString("isbn"), result.getInt("year_published"), result.getString("summary"));
				book.setId(result.getInt("id"));
				book.setGateway(this);
				books.add(book);	
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		} finally {
			try {
				if(result != null)
					result.close();
				if(st != null)
					st.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return books;
	}
	
	
	public BooksTableGateway(){
		connector = null;
		Properties property = new Properties();
		FileInputStream fis = null;
        try {
			fis = new FileInputStream("db.properties");
			property.load(fis);
	        fis.close();

	        MysqlDataSource database = new MysqlDataSource();
	        database.setURL("jdbc:mysql://easel2.fulgentcorp.com:3306/vkw609?serverTimezone=UTC#");
	        database.setUser("vkw609");
	        database.setPassword("XR7Ewbzp2QBZWZXAQczU");
	        
			
			connector = database.getConnection();

        } catch (IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	    
	}

	public void updateBook(Books book) throws GatewayException {
		logger.info("update book");
		PreparedStatement update = null;
		
		try{
			
			connector.setAutoCommit(false);
			logger.info("update book AUTO COMMIT");
			update = connector.prepareStatement("Update BookList " + " set title = ?" 
						+ " , summary = ?" + " , year_published = ?" + ", isbn = ? WHERE id = ?");
			logger.info("update book con prepare");
			update.setString(1, book.getTitle());
			logger.info("update book gettitle");
			update.setString(2, book.getSummary());
			logger.info("update book get summary");
			update.setInt(3, book.getYear());
			logger.info("update book get year");
			update.setString(4, book.getISBN());
			logger.info("update book get IPSN");
			update.setInt(5, book.getId());
			update.executeUpdate();
			logger.info("executeUpdate");
			connector.commit();
			
		} catch (SQLException e) {
		// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			update.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void deleteBook(Books book){
		
		PreparedStatement delete = null;
		try {
			
			delete = connector.prepareStatement("delete from BookList where id = ?");
			delete.setInt(1, book.getId());
			delete.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(delete != null)
					delete.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void addBook(Books book){
		PreparedStatement add = null;
		try {
			add = connector.prepareStatement("insert into BookList (title, isbn, "
					+ "year_published, summary) values (?, ?, ?, ?)");
			add.setString(1, book.getTitle());
			add.setString(2, book.getISBN());
			add.setInt(3, book.getYear());
			add.setString(4, book.getSummary());
			add.executeUpdate();
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(add != null)
					add.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	
	public void close() {
		logger.info("close");
		if(connector != null) {
			try {
				connector.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}

