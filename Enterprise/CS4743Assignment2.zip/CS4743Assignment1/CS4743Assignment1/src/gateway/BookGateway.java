package gateway;

import java.util.List;
import application.Books;

public interface BookGateway {
	
		public List<Books> getBook();
		public void updateBook(Books book) throws GatewayException;
		public void deleteBook(Books book);
		public void addBook(Books book);
		public void close();
}
