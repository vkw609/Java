package view;

public enum ViewType {
	BookDetail, BookList, BookAdd
}

