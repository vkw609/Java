package controllers;

public class PublisherController {

}
